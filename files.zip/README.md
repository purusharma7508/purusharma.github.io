# Puru Sharma | Portfolio

Personal portfolio website of **Puru Sharma**, B.Tech CSE (AI & Data Science) student at JECRC University, Jaipur.

Built with plain HTML, CSS and a little JavaScript. No build step, no dependencies.

## Run locally

Open `index.html` in your browser.

## Edit

Search `index.html` for `TODO` and `YOUR-USERNAME`, then replace them with your own details (about text, projects, years, email, GitHub and LinkedIn links).

## Deploy with GitHub Pages

1. Create a repository named `YOUR-USERNAME.github.io` (or any name).
2. Upload `index.html` and `README.md`.
3. Go to **Settings > Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. Your site goes live at `https://YOUR-USERNAME.github.io` in a minute or two.
